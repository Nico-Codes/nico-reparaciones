<?php

use Illuminate\Support\Facades\Route;

// Rutas API (por ahora no usamos nada)
// Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
//     return $request->user();
// });
