NicoReparaciones - Iconos color (SVG) v2 (más "premium")
-------------------------------------------------------

Copiá los .svg a:
  public/icons/

Usalos así (ejemplo):
  <img src="/icons/tienda.svg" class="w-5 h-5" alt="" loading="lazy" decoding="async">

Incluye:
- tienda.svg
- consultar-reparacion.svg
- carrito.svg
- mis-pedidos.svg
- mis-reparaciones.svg
- logout.svg
- dashboard.svg
- settings.svg
